#!/bin/bash

#$-N traj_00059



PRIMARY_DIR=/mnt/irisgpfs/users/camuller/04_cyanine-project/08_sc-Cy1/trans/geom_sc-Cy1_s0/traj/Singlet_1/TRAJ_00059/

cd $PRIMARY_DIR

$SHARC/sharc.x input
