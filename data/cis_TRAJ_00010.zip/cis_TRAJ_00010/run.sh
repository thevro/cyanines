#!/bin/bash

#$-N traj_00010



PRIMARY_DIR=/mnt/irisgpfs/users/camuller/04_cyanine-project/08_sc-Cy1/cis/geom_sc-Cy1_s10/traj_n/Singlet_1/TRAJ_00010/

cd $PRIMARY_DIR

$SHARC/sharc.x input
